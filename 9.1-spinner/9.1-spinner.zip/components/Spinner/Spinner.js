import React from 'react';
import './Spinner.css';

class Spinner extends React.Component{
 state = {

 };
  
 render(){    
  return(
   <div>
    <div className="spinner-1"></div>
   </div>
  );  
 }
}

export default Spinner;